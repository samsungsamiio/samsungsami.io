//
//  UserInfoViewController.m
//
//  Created by Maneesh Sahu-SSI on 9/17/14.
//  Copyright (c) 2014 SSIC. All rights reserved.
//

#import "SamiDevicesApi.h"
#import "SamiDeviceTypesApi.h"
#import "LoginViewController.h"
#import "SamiUsersApi.h"
#import "UserSession.h"
#import "UserInfoViewController.h"

@interface UserInfoViewController ()
@property (weak, nonatomic) IBOutlet UILabel *fullnameLabel;
@property (weak, nonatomic) IBOutlet UILabel *idLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *createdLabel;
@property (weak, nonatomic) IBOutlet UILabel *modifiedLabel;

@end

@implementation UserInfoViewController {
    SamiDevice *withingsDevice_;
    IBOutlet UIButton *weightButton_;
}

- (void) validateAccessToken {
    [self setWithingsDevice:nil];

    NSString* authorizationHeader = [UserSession sharedInstance].bearerToken;

    SamiUsersApi * usersApi = [[SamiUsersApi alloc] init];
    [usersApi addHeader:authorizationHeader forKey:kOAUTHAuthorizationHeader];
    
    [usersApi selfWithCompletionBlock:^(SamiUserEnvelope *output, NSError *error) {
        
        NSLog(@"%@", error);
        if (error) {
            self.fullnameLabel.text = error.localizedFailureReason;
        } else {
            UserSession *session = [UserSession sharedInstance];
            session.user = output.data;
            
            self.idLabel.text = output.data._id;
            self.nameLabel.text = output.data.name;
            self.fullnameLabel.text = output.data.fullName;
            self.emailLabel.text = output.data.email;
            
            NSDateFormatter * dateFormat = [[NSDateFormatter alloc] init];
            [dateFormat setDateFormat:@"MMM dd, yyyy HH:mm"];
            
            NSDate *created = [NSDate dateWithTimeIntervalSince1970:([output.data.createdOn doubleValue])];
            self.createdLabel.text = [dateFormat stringFromDate:created];
            
            NSDate *modified = [NSDate dateWithTimeIntervalSince1970:([output.data.modifiedOn doubleValue])];
            self.modifiedLabel.text = [dateFormat stringFromDate:modified];
            
            [self processWithingsDevice];
        }        
    }];
}

-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    if([identifier isEqualToString:@"showWithingsData"] && (withingsDevice_ == nil))
    {
        return NO;
    }
    return YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showDevices"]) {
        NSLog(@"Show devices");
    } else if ([segue.identifier isEqualToString:@"showAuth"]) {
        NSLog(@"Show Auth");
        UserSession *session = [UserSession sharedInstance];
        [session logout];
    } else if ([segue.identifier isEqualToString:@"showWithingsData"]) {
        NSLog(@"show WithingsData");
        [segue.destinationViewController performSelector:@selector(setDevice:) withObject:withingsDevice_];
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    UserSession *session = [UserSession sharedInstance];
    if (!session.user) {
        [self validateAccessToken];
    }
   
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UserSession *session = [UserSession sharedInstance];
    if (!session.accessToken) {
        [self performSegueWithIdentifier:@"showAuth" sender:self];
    }
}

- (void)processWithingsDevice {
    [self setWithingsDevice:nil];

    NSString* authorizationHeader = [UserSession sharedInstance].bearerToken;
    
    SamiUsersApi * api = [[SamiUsersApi alloc] init];
    [api addHeader:authorizationHeader forKey:kOAUTHAuthorizationHeader];
    
    [api getUserDevicesWithCompletionBlock:@(0) count:@(100) includeProperties:@(YES) userId:[UserSession sharedInstance].user._id completionHandler:^(SamiDevicesEnvelope *output, NSError *error) {
        NSLog(@"%@", output.data.devices);
        NSArray *devices = output.data.devices;

        NSPredicate *predicateMatch = [NSPredicate predicateWithFormat:@"dtid == %@", kDeviceTypeID_Withings];
        NSArray *withingsDevice = [devices filteredArrayUsingPredicate:predicateMatch];
        if ([withingsDevice count] >0) {
            NSLog(@"Found %lu Withings devices", (unsigned long)[withingsDevice count]);
            [self setWithingsDevice:((SamiDevice *)withingsDevice[0])];
         } else {
            NSLog(@"Found 0 Withings devices");
        }
    }];
}

- (void)setWithingsDevice:(SamiDevice *)device
{
    if (device != nil) {
        withingsDevice_ = device;
        weightButton_.enabled = YES;
    } else {
        withingsDevice_ = nil;
        weightButton_.enabled = NO;
    }
}

@end
