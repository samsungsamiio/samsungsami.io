//
//  LoginViewController.h
//  SAMIHMonitor
//
//  Copyright (c) 2014 SSIC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController<UIWebViewDelegate>

@end
