//
//  DataTableViewController.m
//  SAMIHMonitor
//
//  Copyright (c) 2015 SSIC. All rights reserved.
//

#import "DataTableViewController.h"
#import "SamiMessagesApi.h"
#import "UserSession.h"
#import "SamiDeviceTypesApi.h"

@interface DataTableViewController ()
@property (nonatomic) UIRefreshControl *refreshControl;
@property (nonatomic) NSArray * messages;
@property (nonatomic) NSDateFormatter *dateFormat;
@end

@implementation DataTableViewController
{
    SamiNormalizedMessage *normalizedMessage_;
    SamiDevice *device_;
    NSString *unit_;
}

- (void)setDevice:(SamiDevice *)device
{
    device_ = device;
    NSLog(@"Set Device with sid %@", device_._id);
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.dateFormat = [[NSDateFormatter alloc] init];
    [self.dateFormat setDateFormat:@"MMM dd, yyyy HH:mm"];
    
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(refreshMessages) forControlEvents:UIControlEventValueChanged];
    self.refreshControl = refreshControl;
    
    [self parseManifestSetUnit];
    [self refreshMessages];
}

- (void)refreshMessages {
    NSString *authorizationHeader = [UserSession sharedInstance].bearerToken;
    int messageCount = 20;

    SamiMessagesApi * api2 = [SamiMessagesApi apiWithHeader:authorizationHeader key:kOAUTHAuthorizationHeader];
    [api2 getLastNormalizedMessagesWithCompletionBlock:@(messageCount) sdids:device_._id fieldPresence:nil completionHandler:^(SamiNormalizedMessagesEnvelope *output, NSError *error) {
        self.messages = output.data;
        [self.tableView reloadData];
        [self.refreshControl endRefreshing];
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.messages.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MessageCell" forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MessageCell"];
    }
    SamiNormalizedMessage *message = (SamiNormalizedMessage *)[self.messages objectAtIndex:indexPath.row];
    
    NSDictionary *dict = message.data;
    id value = [dict objectForKey:@"weight"];
    cell.textLabel.text = [value description];
    
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:([message.ts doubleValue]/1000)];
    cell.detailTextLabel.text = [self.dateFormat stringFromDate:date];
    
    return cell;
}

#pragma mark - Misc

- (void)parseManifestSetUnit {
    NSString* authorizationHeader = [UserSession sharedInstance].bearerToken;
    
    SamiDeviceTypesApi * api = [[SamiDeviceTypesApi alloc] init];
    [api addHeader:authorizationHeader forKey:kOAUTHAuthorizationHeader];
    
    [api getLatestManifestPropertiesWithCompletionBlock:device_.dtid completionHandler:^(SamiManifestPropertiesEnvelope *output, NSError *error) {
        NSLog(@"%@ %@", output, error);
        
        NSDictionary *dict = [output.data.properties objectForKey:@"fields"];
        NSDictionary *fieldInfo = [dict objectForKey:@"weight"];
        unit_ = [fieldInfo objectForKey:@"unit"];
        NSString *fieldName = @"Weight in ";
        NSString *titleWithUnit = [fieldName stringByAppendingString:unit_];
        self.navigationItem.title = titleWithUnit;
    }];
    
}

@end
