//
//  SamiConstants.m
//  SAMIHMonitor
//
//  Copyright (c) 2015 SSIC. All rights reserved.
//

#import "SamiConstants.h"

NSString *const kSAMIClientID = @"<YOUR CLIENT APP ID>";

NSString *const kAccessToken = @"access_token";

NSString *const kSAMIAuthBaseUrl = @"https://accounts.samsungsami.io";
NSString *const kSAMIAuthPath = @"/authorize";
NSString *const kSAMIRedirectUrl = @"ios-app://redirect";
NSString *const kSAMIDeviceID = @"SAMI_DEVICE_ID";

NSString *const kOAUTHAuthorizationHeader = @"Authorization";
NSString *const kOAUTHBearerTokenFormat = @"Bearer %@";

NSString *const kDeviceTypeID_Withings = @"dt29673f0481b4401bb73a622353b96150";