//
//  AppDelegate.h
//  SAMIHMonitor
//
//  Copyright (c) 2014 SSIC. All rights reserved.
//

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
