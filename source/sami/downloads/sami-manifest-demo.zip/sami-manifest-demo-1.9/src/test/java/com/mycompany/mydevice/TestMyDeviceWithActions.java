package com.mycompany.mydevice;

import com.samsung.sami.manifest.ManifestUtil;
import com.samsung.sami.manifest.SamiManifest;
import com.samsung.sami.manifest.actions.Action;
import com.samsung.sami.manifest.fields.Field;
import com.samsung.sami.manifest.test.ManifestTest;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.Map;

/**
 * Sample test case
 */
public class TestMyDeviceWithActions extends ManifestTest {

    @Test
    public void testMyDeviceManifest() throws IOException {
        String manifestPath = "/manifests/MyDeviceWithActionsManifest.groovy";
        String dataPath = "/data/myDeviceData.csv";
        runManifestTest(manifestPath, dataPath);
    }

    private void runManifestTest(String manifestPath, String dataPath) throws IOException {
        Map<String, Field> fields = runGroovyManifest(manifestPath, dataPath);

        Assert.assertNotNull(fields);
        Assert.assertFalse(fields.isEmpty());
        printManifestRunResults(fields);

        // Verify that the Manifest produces the correct value for each field
        Assert.assertEquals(62, fields.get("noise").getValue());
        Assert.assertEquals(602, fields.get("co2").getValue());
        // Verify the value where there is data conversion.
        // The input raw unit is FAHRENHEIT while the normalized unit is CELSIUS 
        int tempInCelsius = (65-32)* 5/9;
        Assert.assertEquals(tempInCelsius, fields.get("temp").getValue());
    }

    private void printManifestRunResults(Map<String, Field> fields) {
        for (Field field : fields.values())
            System.out.println(field.toString());
    }

    @Test
    public void testMyDeviceManifestWithActions() throws IOException {
        String manifestPath = "/manifests/MyDeviceWithActionsManifest.groovy";

        // check and print actions
        SamiManifest manifest = ManifestUtil.parseManifest(readFile(manifestPath));
        Map<String, Action> actions = manifest.getActions();

        Assert.assertTrue(actions.containsKey("setWarningOn"));
        Assert.assertTrue(actions.containsKey("setWarningOff"));
        Assert.assertTrue(actions.containsKey("setColorAsRGB"));

        // print the actions
        for (Action action: actions.values()) {
            System.out.println(action);
        }
    }
}
