package com.mycompany.mydevice;

import com.samsung.sami.manifest.fields.Field;
import com.samsung.sami.manifest.test.ManifestTest;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.Map;

/**
 * Sample test case
 */
public class TestMyDevice extends ManifestTest {

    @Test
    public void testMyDeviceManifest() throws IOException {
        String manifestPath = "/manifests/MyDeviceManifest.groovy";
        String dataPath = "/data/myDeviceData.csv";
        runManifestTest(manifestPath, dataPath);
    }

    private void runManifestTest(String manifestPath, String dataPath) throws IOException {
        Map<String, Field> fields = runGroovyManifest(manifestPath, dataPath);

        Assert.assertNotNull(fields);
        Assert.assertFalse(fields.isEmpty());
        printManifestRunResults(fields);

        // Verify that the Manifest produces the correct value for each field
        Assert.assertEquals(62, fields.get("noise").getValue());
        Assert.assertEquals(602, fields.get("co2").getValue());
        // Verify the value where there is data conversion.
        // The input raw unit is FAHRENHEIT while the normalized unit is CELSIUS 
        int tempInCelsius = (65-32)* 5/9;
        Assert.assertEquals(tempInCelsius, fields.get("temp").getValue());
    }

    private void printManifestRunResults(Map<String, Field> fields) {
        for (Field field : fields.values())
            System.out.println(field.toString());
    }

}
