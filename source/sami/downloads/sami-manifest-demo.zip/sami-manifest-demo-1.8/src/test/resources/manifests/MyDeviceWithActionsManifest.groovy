package manifests

import com.samsung.sami.manifest.Manifest
import com.samsung.sami.manifest.actions.Action
import com.samsung.sami.manifest.actions.Actionable
import com.samsung.sami.manifest.fields.*
import static com.samsung.sami.manifest.fields.StandardFields.*

import javax.measure.unit.NonSI

public class MyDeviceManifest implements Manifest, Actionable {
    public final static FieldDescriptor TEMP_INTEGER = TEMPERATURE.alias(Integer.class)
    public final static FieldDescriptor NOISE = new FieldDescriptor("noise", "environmental noise", NonSI.DECIBEL, Integer.class);
    public final static FieldDescriptor CO2 = new FieldDescriptor("co2", StandardUnits.PARTS_PER_MILLION, Integer.class);

    @Override
    List<Field> normalize(String input) {
        def fields = []
        def values = input.split(",")
        def tempInF = values[0].asType(Integer.class)
        def noise = values[1].asType(Integer.class)
        def co2 = values[2].asType(Integer.class)

        fields.add(new Field(TEMP_INTEGER, NonSI.FAHRENHEIT, tempInF))
        fields.add(new Field(NOISE, noise))
        fields.add(new Field(CO2, co2))

        return fields
    }
    @Override
    List<FieldDescriptor> getFieldDescriptors() {
        return [TEMP_INTEGER, NOISE, CO2]
    }

    // Actions parameters
    static final INTENSITY = new FieldDescriptor("intensity", "Light intensity (0-255)", Integer.class);

    @Override
    List<Action> getActions() {
        return [
            new Action("setWarningOn", "Sets the warning light on"),
            new Action("setWarningOff", "Sets the warning light off"),
            new Action("setColorAsRGB", "Changes the warning light color with RGB values and set the intensity (0-255)",
                COLOR_AS_RGB, INTENSITY
            )
        ]
    }
}