import com.samsung.sami.manifest.Manifest
import com.samsung.sami.manifest.fields.*
import static com.samsung.sami.manifest.fields.StandardFields.*

import javax.measure.unit.NonSI

public class MyDeviceManifest implements Manifest {

    public final static FieldDescriptor TEMP_INTEGER = TEMPERATURE.alias(Integer.class)
    public final static FieldDescriptor NOISE = new FieldDescriptor("noise", "environmental noise", NonSI.DECIBEL, Integer.class);
    public final static FieldDescriptor CO2 = new FieldDescriptor("co2", StandardUnits.PARTS_PER_MILLION, Integer.class);

    @Override
    List<Field> normalize(String input) {
        def fields = []
        def values = input.split(",")
        def tempInF = values[0].asType(Integer.class)
        def noise = values[1].asType(Integer.class)
        def co2 = values[2].asType(Integer.class)

        fields.add(new Field(TEMP_INTEGER, NonSI.FAHRENHEIT, tempInF))
        fields.add(new Field(NOISE, noise))
        fields.add(new Field(CO2, co2))

        return fields
    }
    @Override
    List<FieldDescriptor> getFieldDescriptors() {
        return [TEMP_INTEGER, NOISE, CO2]
    }
}