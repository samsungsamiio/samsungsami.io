<?php
/**
 * sami-helper.php
 * SAMI helper class that communicates to SAMI using user/pass and implicit grant
 * */
class SAMI {
    # General Configuration
    const CLIENT_ID = "xxxxx";
    const DEVICE_ID = "xxxxx";
    const API_URL = "https://api.samsungsami.io/v1.1";
    const WEBSOCKET_URL = "wss://api.samsungsami.io/v1.1";
    const ACCOUNTS_URL = "https://accounts.samsungsami.io/";
    const REDIRECT_URI = "http://localhost:81/samidemo/index.php";
 
    # SAMI API paths
    const API_USERS_SELF = "/users/self";
    const API_USERS_DEVICES = "/users/<USER_ID>/devices";
    const API_MESSAGES_LAST = "/messages/last?sdids=<DEVICES>&count=<COUNT>"; 
    const API_MESSAGES = "/messages?sdid=<DEVICE_ID>&count=<COUNT>&startDate=<START_DATE>&endDate=<END_DATE>&order=<ORDER>";
    const API_MESSAGES_POST = "/messages";
    const API_WEBSOCKET = "/websocket";
    const API_LIVE = "/live";
    const API_AUTHORIZE = "/authorize";
    const API_LOGOUT = "/logout";
     
    # Members
    public $token = null;
    public $user = null;
     
    public function __construct(){ }
     
    /**
     * Returns the URL to login in SAMI Accounts
     */
    public function getLoginUrl(){
        return SAMI::ACCOUNTS_URL.SAMI::API_AUTHORIZE."?response_type=token&client_id=".SAMI::CLIENT_ID;
    }
     
    /**
     * Returns the URL to logout from SAMI Accounts
     */
    public function getLogoutUrl(){
        return SAMI::ACCOUNTS_URL.SAMI::API_LOGOUT."?redirect_uri=".SAMI::REDIRECT_URI;
    }
     
    /**
     * Returns the URL to connect to the /live websocket endpoint
     * Ex: /v1.1/live?userId=<USER_ID>&Authorization=bearer+<ACCESS_TOKEN>
     */
    public function getLiveWebsocketUrl(){
        return SAMI::WEBSOCKET_URL . SAMI::API_LIVE . '?userId=' . $this->user->data->id . '&Authorization=bearer+' . $this->token;
    }
     
    /**
     * Sets the access token and looks for the user profile information
     */
    public function setAccessToken($someToken){
        $this->token = $someToken;
        $this->user = $this->getUsersSelf();
    }
     
    /**
     * API call GET
     */
    public function getCall($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPGET, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization:bearer '.$this->token));
        $json = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if($status == 200){
            $response = json_decode($json);
        }
        else{
            var_dump($json);
        	$response = $json;
        }

       return $response;
    }
     
    /**
     * API call POST
     */
    public function postCall($url, $payload){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, (String) $payload);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: bearer '.$this->token));
        $json = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if($status == 200){
            $response = json_decode($json);
        }
        else{
            var_dump($json);
            $response = $json;
        }
        return $response;
    }
     
    /**
     * GET /users/self API
     */
    public function getUsersSelf(){
        return $this->getCall(SAMI::API_URL . SAMI::API_USERS_SELF);
    }
     
    /**
     * GET /users/uid/devices API
     */
    public function getUserDevices($userId){
        return $this->getCall(SAMI::API_URL . str_replace("<USER_ID>", $userId, SAMI::API_USERS_DEVICES));
    }
     
    /**
     * POST /message API
     */
    public function sendMessage($payload){
        return $this->postCall(SAMI::API_URL . SAMI::API_MESSAGES_POST, $payload);
    }
     
    /**
     * GET /historical/normalized/messages/last API
     */
    public function getMessagesLast($deviceCommaSeparatedList, $countByDevice){
        $apiPath = SAMI::API_MESSAGES_LAST;
        $apiPath = str_replace("<DEVICES>", $deviceCommaSeparatedList, $apiPath);
        $apiPath = str_replace("<COUNT>", $countByDevice, $apiPath);
        return $this->getCall(SAMI::API_URL.$apiPath);
    }
     
    /**
     * GET /historical/normalized/messages API
     */
    public function getMessages($sdid, $count, $startDate, $endDate, $order){
        $apiPath = SAMI::API_MESSAGES;
        $apiPath = str_replace("<DEVICE_ID>", $sdid, $apiPath);
        $apiPath = str_replace("<COUNT>", $count, $apiPath);
        $apiPath = str_replace("<START_DATE>", $startDate, $apiPath);
        $apiPath = str_replace("<END_DATE>", $endDate, $apiPath);
        $apiPath = str_replace("<ORDER>", $order, $apiPath);
        return $this->getCall(SAMI::API_URL.$apiPath);
    }
     
    /**
     * SAMI has milliseconds based timestamps, returns the current date
     */
    function currentTimeMillis() {
        $microtime = microtime();
        $comps = explode(' ', $microtime);
        return sprintf('%d%03d', $comps[1], $comps[0] * 1000);
    }
}