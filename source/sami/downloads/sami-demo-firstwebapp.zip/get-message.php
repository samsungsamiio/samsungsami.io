<?php
session_start();
require('sami-helper.php');
$sami = new SAMI();
$sami->setAccessToken($_SESSION["access_token"]);
$messageCount = 1;
$response = $sami->getMessagesLast(SAMI::DEVICE_ID, $messageCount);
header('Content-Type: application/json');
echo json_encode($response);
