<?php
session_start();
require('SamiConnector.php');
$sami = new SamiConnector();
$sami->setAccessToken($_SESSION["access_token"]);
$messageCount = 1;
$response = $sami->getMessagesLast(SamiConnector::DEVICE_ID, $messageCount);
header('Content-Type: application/json');
echo json_encode($response);
