/*
SAMI Demo
Copyright 2014 Tictrac Ltd

Licensed under the MIT License
http://www.opensource.org/licenses/MIT
*/
package websockets

import (
	"code.google.com/p/go.net/websocket"
	"errors"
	"fmt"
	"io"
)

/*
Reads a sequence of messages from a websocket.
 */
func GetMessage(ws *websocket.Conn) (string, error) {
	var msg string
	err := websocket.Message.Receive(ws, &msg)
	if err != nil {
		if err == io.EOF {
			fmt.Println("Disconnected " + err.Error() + " " + msg)
			return "", errors.New("Disconnected")
		}
		fmt.Println("Couldn't receive msg " + err.Error())
		return "", errors.New("Couldn't receive msg")
	}
	return msg, err
}
