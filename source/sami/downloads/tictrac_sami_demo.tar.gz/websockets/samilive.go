/*
SAMI Demo
Copyright 2014 Tictrac Ltd

Licensed under the MIT License
http://www.opensource.org/licenses/MIT
*/
package websockets

import (
	"code.google.com/p/go.net/websocket"
	"fmt"
	"../parsers"
)

/*
Reads Simba messages from the SAMI live websocket, parses them into the Simba
data structure and feeds them into the supplied channel.
 */
func SAMILiveSocket(socket_uri string, messages chan<- *parsers.SimbaMessage) {
	fmt.Println("Connecting to SAMI on ", socket_uri)
	samiConn, err := websocket.Dial(socket_uri, "", "http://localhost")

	if err != nil {
		fmt.Println("Error connecting socket " + err.Error())
		return
	}

	for {
		msg, err := GetMessage(samiConn)
		samiMsg := parsers.ParseSimbaMessage([]byte(msg))
		if err == nil {
			messages <- &samiMsg
		} else {
		    fmt.Println("Couldn't receive message")
		    break
		}
	}
	samiConn.Close()
	fmt.Println("Server Closing")
}
