/*
SAMI Demo
Copyright 2014 Tictrac Ltd

Licensed under the MIT License
http://www.opensource.org/licenses/MIT
*/
package api

import (
	"io/ioutil"
	"log"
	"net/http"
	"../parsers"
)

/*
Retrieves a users SAMI profile. This is necessary to determine
the websocket uri that should be used to listen for SAMI messages.
 */
func GetUserProfile(token string) parsers.UserProfile {
    user_url := base_url + "/users/self"

    client := &http.Client{}

    req, err := http.NewRequest("GET", user_url, nil)
    req.Header.Add("Authorization", "Bearer " + token)
    req.Header.Add("Content-Type", "application/json")
    resp, err := client.Do(req)
	if err != nil {
		log.Fatal("GetUserProfile: ", err)
	}
	defer resp.Body.Close()

    body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatal("GetUserProfile: ", err)
	}

    user := parsers.ParseUserProfile(body)

	return user
}

/*
Retrieves the SAMI live URI for the current user. This can be
connected and listened on for messages streaming through SAMI.
 */
func GetSAMILiveURL(token string) (string, string) {
	user := GetUserProfile(token)
	return "wss://api.samihub.com:443/v1.1/live?userId=" + user.Id + "&Authorization=bearer+" + token, user.Id
}
