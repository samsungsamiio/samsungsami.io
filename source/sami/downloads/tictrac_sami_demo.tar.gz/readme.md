SAMI Demo
=========

This package contains an example implementation of connecting to a live Samsung SAMI
websocket and interpreting messages coming from a Simba / Simband device. These messages
are translated and delivered to a client application via another websocket for processing
and / or visualisation.

Note that due to this system operating on the live websocket, another service must be
publishing data to the account that is used to authorise the application. In the past, the
SAMIHub wizard has been used for this purpose, using the Simba Canned Data 0514 and Simba
E2E demo recorded samples datasets.

Configuration
-------------

* Install golang dependencies (requires golang >= 1.1)
 * go get code.google.com/p/go.net/websocket
 * go get code.google.com/p/goauth2/oauth
 * go get github.com/go-martini/martini

* Update demo.go to set the OAuth credentials
 * Set SAMIClientId
 * Set SAMIClientSecret

General Operation
-----------------

* Start the server (go run demo.go)
* Connect to the webserver in a browser on http://localhost:8000
* Go through the SAMI OAuth process to obtain a token
* At the end of the previous step, if the token was successful the server will connect to SAMI
* Point a client application at ws://localhost:8000/stream (or use http://localhost:8000/client)

Licence and Copyright
---------------------
Licensed under the MIT License. See LICENCE.

Copyright (c) 2014 Tictrac Ltd
