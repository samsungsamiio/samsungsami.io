/*
SAMI Demo
Copyright 2014 Tictrac Ltd

Licensed under the MIT License
http://www.opensource.org/licenses/MIT
*/
package parsers

type Datapoint struct {
	X		int				`json:"x"`
	Y		float64			`json:"y"`
}

type DataSeries struct {
	Key		string			`json:"key"`
	Values	[]Datapoint		`json:"values"`
}

type UserProfile struct {
    Id          string
    Name        string
    Email       string
    FullName    string
    CreatedOn   int
    ModifiedOn  int
}

type UserProfileContainer struct {
    Data    UserProfile
}

type SimbaMetaData struct {
	Channels	int
	SampleRate	int
	ContentType	string
	Origin		string
	SensorType	string
}

type SimbaData struct {
	Metadata	SimbaMetaData
	Content		interface{}
}

type SimbaMessage struct {
    Mid			string
	Ts			int
	Sdtid		string
	Cts			int
	Uid			string
	Mv			int
	Sdid		string
	Data		SimbaData
}
