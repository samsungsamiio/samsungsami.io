/*
SAMI Demo
Copyright 2014 Tictrac Ltd

Licensed under the MIT License
http://www.opensource.org/licenses/MIT
*/
package parsers

import (
	"encoding/json"
	"log"
)

/*
Creates a SimbaMessage from a bytestream
 */
func ParseSimbaMessage(data []byte) SimbaMessage {
    var msg SimbaMessage
    err := json.Unmarshal(data, &msg)
	if err != nil {
		log.Fatal("ParseSimbaMessage:", err)
	}
	return msg
}

/*
Parses the data contents of a SimbaMessage. This will also use the SampleRate
to extrapolate a data series into an x,y time series of time, value. This means
that the processing required on the front end side should be minimal.

Uses the channel name as the identifiable parameter for the data series.
 */
func ParseDatapoints(msg *SimbaMessage) (string, []Datapoint) {
	var name string = ""
	var datapoints []Datapoint = nil

	if (msg.Sdtid == "simba_device") {
		// Calculate time parameters
		startTime := msg.Ts
		interval := 1000.0 / float64(msg.Data.Metadata.SampleRate * msg.Data.Metadata.Channels)

		// The data structure is a map of channel name -> array of floats. There will only
		// ever be one key / name.
		data := msg.Data.Content.(map[string]interface{})
		for _name, v := range data {
			list := v.([]interface{})
			datapoints = make([]Datapoint, len(list))

			// Extrapolate all the values across the time period
			for index, value := range list {
				datapoints[index] = Datapoint {
					X: startTime + int(float64(interval) * float64(index)),
					Y: value.(float64),
				}
			}
			name = _name
		}
	}

	return name, datapoints
}
