/*
SAMI Demo
Copyright 2014 Tictrac Ltd

Licensed under the MIT License
http://www.opensource.org/licenses/MIT
*/
package parsers

import (
	"encoding/json"
	"log"
)

/*
Decodes a UserProfile message from a bytestream
 */
func ParseUserProfile(data []byte) UserProfile {
    var user UserProfileContainer
    err := json.Unmarshal(data, &user)
	if err != nil {
		log.Fatal("ParseUserProfile:", err)
	}
	return user.Data
}
