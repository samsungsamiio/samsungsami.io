/*
SAMI Demo
Copyright 2014 Tictrac Ltd

Licensed under the MIT License
http://www.opensource.org/licenses/MIT
*/

package main

import (
	"fmt"
	"net/http"
	"code.google.com/p/go.net/websocket"
	"github.com/go-martini/martini"
	"encoding/json"
	"io/ioutil"
	"./auth"
	"./api"
	"./websockets"
	"./parsers"
)

// Channel to receive messages from SAMI
var inbound_messages = make(chan *parsers.SimbaMessage)
// Channel to transmit translated messages
var outbound_messages = make(chan []byte)

/*
Retrieves an OAuth Token to be authorised by the SAMI platform
 */
func getToken(w http.ResponseWriter, r *http.Request) {
	fmt.Println("getToken")
	auth_url := auth.GetTokenURL()
	http.Redirect(w, r, auth_url, http.StatusFound)
}

/*
Exchanges an authorisation token for an OAuth Access  Token
 */
func authToken(w http.ResponseWriter, r *http.Request) {
	fmt.Println("authToken")

	code := r.URL.Query().Get("code")
	token := auth.AuthoriseToken(code)

	http.SetCookie(w, &http.Cookie{Name: "tt-oauth-token", Value: token})

	http.Redirect(w, r, "/start?token=" + token, http.StatusFound)
}

/*
Reads messages from the SAMI channel, translates them and transmits
them to the outbound channel
 */
func samiTranslator() {
	for {
		msg := <- inbound_messages
		name, points := parsers.ParseDatapoints(msg)
		if points != nil {
			var values [1]parsers.DataSeries
			values[0] = parsers.DataSeries{
				Key: name,
				Values: points,
			}
			d, _ := json.Marshal(values)
			outbound_messages <- d
			fmt.Printf("%v sent %v points\n", name, len(points))
		}
	}
}

/*
Connects to the SAMI livesocket and streams messages into the inbound
channel for translation.
 */
func connectToSami(w http.ResponseWriter, r *http.Request) {
	token := r.URL.Query().Get("token")
	sami_socket_uri, identifier := api.GetSAMILiveURL(token)
	fmt.Printf("%+v %v\n", sami_socket_uri, identifier)

	go websockets.SAMILiveSocket(sami_socket_uri, inbound_messages)

	fmt.Fprintf(w, "Websocket now running on ws://localhost:8000/stream")
}

/*
Accepts websocket requests from clients that want to read the translated
messages. NOTE: This will only support one client concurrently.
 */
func streamTranslatedMessages(w http.ResponseWriter, r *http.Request) {
    client := websocket.Server{Handler: websocket.Handler(translatedMessagesStreamHandler)}
    client.ServeHTTP(w, r)
}

/*
Reads translated messages from the outbound channel and transmits them
to a connected client websocket.
 */
func translatedMessagesStreamHandler(client *websocket.Conn) {
	for {
		data := <- outbound_messages

		err := websocket.Message.Send(client, string(data[:]))
		if (err != nil) {
			break
		}
	}
}

/*
Simple way of serving up the client.html. A developer could just as easily load
the file locally in a browser
 */
func serveClientHTML(w http.ResponseWriter, r *http.Request) {
    filename := "client.html"
    body, err := ioutil.ReadFile(filename)
    if (err == nil) {
	    fmt.Fprintf(w, "%s", body);
	}
}

func main() {
	// Start the translator
	go samiTranslator()

	// Configure OAuth setings
	var SAMIClientId = "REPLACEME"
	var SAMIClientSecret = "REPLACEME"
	auth.OAuthClientId = SAMIClientId;
	auth.OAuthClientSecret = SAMIClientSecret;

	// Start the webserver
	m := martini.Classic()
	m.Get("/client", serveClientHTML)
	m.Get("/start", connectToSami)
	m.Get("/stream", streamTranslatedMessages)
	m.Get("/authorize", authToken)
	m.Get("/", getToken)
	http.ListenAndServe(":8000", m)
}
