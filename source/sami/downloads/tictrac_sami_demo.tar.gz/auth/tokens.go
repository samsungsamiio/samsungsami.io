/*
SAMI Demo
Copyright 2014 Tictrac Ltd

Licensed under the MIT License
http://www.opensource.org/licenses/MIT
*/
package auth

import (
	"log"
	"net/url"
    "code.google.com/p/goauth2/oauth"
)

var OAuthClientId = "";
var OAuthClientSecret = ""

/*
Sets up OAuth configuration for SAMI
 */
func getConfig() oauth.Config {
	return oauth.Config{
		ClientId:     OAuthClientId,
		ClientSecret: OAuthClientSecret,
		RedirectURL:  "",
		Scope:        "read,write",
		AuthURL:      "https://accounts.samihub.com/authorize",
		TokenURL:     "https://accounts.samihub.com/token",
	}
}

/*
Retrieves the URL to use for authorising OAuth tokens
 */
func GetTokenURL() string {
	config := getConfig()
	return config.AuthCodeURL("")
}

/*
Performs token authorisation. Technically this should be
handled within the goauth2 library, however the params need
to be supplied on the query string, which the goauth2 library
has no configuration to do.
 */
func AuthoriseToken(code string) string {
	config := getConfig()
	transport := &oauth.Transport{Config: &config}
    params := url.Values{
		"grant_type":   {"authorization_code"},
		"redirect_uri": {transport.RedirectURL},
		"scope":        {transport.Scope},
		"code":         {code},
	}

	transport.TokenURL += "?" + string(params.Encode())
	token, err := transport.Exchange(code)
	if err != nil {
		log.Fatal("AuthoriseToken:", err)
	}

	return token.AccessToken
}
